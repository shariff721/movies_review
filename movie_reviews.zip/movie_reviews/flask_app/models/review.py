from flask_app.config.mysqlconnection import connectToMySQL

from flask_app.models import user

from flask import flash